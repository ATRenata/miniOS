// void terminate(PCB *p);
int myinit(FILE *p);
void scheduler();
void boot();
