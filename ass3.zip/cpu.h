void initCPU();
void setCPU(FILE *PC, int pcb_offset);
int runCPU(int quanta, PCB *pcb);
