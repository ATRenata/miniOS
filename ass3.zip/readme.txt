mimi.cs.mcgill.ca

1. My countTotalPages does not function, so I purposefully placed 2 as the maximum number of pages to read.
